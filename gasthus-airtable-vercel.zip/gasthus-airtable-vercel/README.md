# Gästhusbokning med Airtable + Vercel

## Airtable-tabell
Skapa en tabell som heter `Bookings` med fälten:

- `Name` - Single line text
- `Start` - Date
- `End` - Date

## Vercel Environment Variables
Lägg in dessa i Vercel:

- `AIRTABLE_TOKEN`
- `AIRTABLE_BASE_ID`
- `AIRTABLE_TABLE_NAME` = `Bookings`

Efter det: redeploy projektet.
